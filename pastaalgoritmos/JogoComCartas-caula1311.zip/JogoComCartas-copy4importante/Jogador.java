import java.util.ArrayList;

// extends é uma keyword que implementa conceito de herança.
//subclass de utlizador
class Jogador extends Utilizador

{
    int pontos;
    String nomeNoJogo;
    Carta cartaDoJogador;
    ArrayList<Carta> maojogador;
    
    
    Jogador ()
    {
        
    }
    void comprarCarta()
    {
        
    }
    void descartarCarta()
    {
        
    }
    void mostrarMao()
    {
        
    }
    
}